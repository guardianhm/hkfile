Portable Skype Launcher 2.0.0.76
================================
Copyright (C) 2006 Rob Loach (http://www.robloach.net)
Portions Copyright 2004-2005 John T. Haller

Website: None yet

This software is OSI Certified Open Source Software.
OSI Certified is a certification mark of the Open Source Initiative.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

ABOUT PORTABLE SKYPE
====================
The Portable Skype Launcher allows you to run Skype from a removable drive whose letter changes as you move it to another computer.  The applicatoin and the profile can be entirely self-contained on the drive and then used on any Windows computer.

LICENSE
=======
This code is released under the GPL.  Within the PortableSkypeCode directory you will find the code (PortableSkype.nsi) as well as the full GPL license (License.txt).  If you use the launcher or code, please give proper and prominent attribution.


INSTALLATION / DIRECTORY STRUCTURE
==================================
By default, the program expects one of these directory structures:

-\ <--- Directory with PortableSkype.exe
  +\skype\
  +\profile\

OR

-\ <--- Directory with PortableSkype.exe
  +\PortableSkype\
    +\skype\
    +\profile\

OR

-\ <--- Directory with PortableSkype.exe
  +\PortableApps\
    +\PortableSkype\
      +\skype\
      +\profile\

OR

-\ <--- Directory with PortableSkype.exe (PortableApps, for instance)
  +\Apps\
    +\PortableSkype\
      +\skype\
      +\plugins\ (optional)
  +\Data\
    +\PortableSkype\
      +\profile\

OR

-\ <--- Directory with PortableSkype.exe (PortableApps, for instance)
  +\Apps\
    +\PortableSkype\
      +\skype\
  +\Data\
    +\PortableSkype\
      +\profile\

It can be used in other directory configurations by including the PortableSkype.ini file in the same directory as PortableSkype.exe and configuring it as details in the INI file section below.  The INI file may also be placed in a subdirectory of the directory containing PortableSkype.exe called PortableSkype or 2 directories deep in PortableApps\PortableSkype or Data\PortableSkype.  All paths in the INI should remain relative to the EXE and not the INI.


PORTABLESKYPE.INI CONFIGURATION
=================================
The Portable Skype Launcher will look for an ini file called PortableSkype.ini within its directory.  If you are happy with the default options, it is not necessary, though.  The INI file is formatted as follows:

[PortableSkype]
SkypeDirectory=skype
ProfileDrectory=profile
AdditionalParameters=
AllowMultipleInstances=false
WaitForSkype=false
SkypeExecutable=skype.exe
DisableSplashScreen=True
StartMinimized=True

The SkypeDirectory and ProfileDrectory should be set to the *relative* path to the directories containing skype.exe, your profile, your plugins, etc. from the current directory.  All must be a subdirectory (or multiple subdirectories) of the directory containing PortableSkype.exe.  The default entries for these are described in the installation section above.  The AppDataDirectory and UserProfileDirectory are used instead of the local User and Application Data directories contained in Documents and Settings.  A blank entry for PluginsDirectory, AppDataDirectory or UserProfileDirectory will disable that feature.

The AdditionalParameters entry allows you to pass additional commandline parameter entries to Skype.exe.  Whatever you enter here will be appended to the call to Skype.exe.

The AllowMultipleInstances entry will allow Portable Skype to run alongside your regular local copy of Skype if you set it to true (lowercase).  The default is false.

The WaitForSkype entry allows you to set the Portable Skype Launcher to wait for Skype to close before it closes.  This option is mainly of use when PortableSkype.exe is called by another program that awaits it's conclusion to perform a task.  It is useful when used with the PortableSkypeLive launcher.

The SkypeExecutable entry allows you to set the Portable Skype Launcher to use an alternate EXE call to launch Skype.  This is helpful if you are using a machine that is set to deny skype.exe from running.  You'll need to rename the skype.exe file and then enter the name you gave it on the Skypeexecutable= line of the INI.

The DisableSplashScreen entry allows you to run the Portable Skype Launcher without the splash screen showing up.  The default is false.

StartMinimized allows you to determine whether Skype should start minimized.


PROGRAM HISTORY / ABOUT THE AUTHORS
===================================
Portable Skype was written by Rob Loach as a port from Portable Miranda by John T. Haller.


CURRENT LIMITATIONS
===================
WRITE ACCESS REQUIRED - The profile directory must be writeable on the USB drive. Drives with a writable switch can not be in read-only mode.