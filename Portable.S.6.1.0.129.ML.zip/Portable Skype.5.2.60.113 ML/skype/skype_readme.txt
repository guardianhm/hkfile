Put skype.exe in this directory.

It is not distributed with Portable Skype to abide to the Skype legalities.